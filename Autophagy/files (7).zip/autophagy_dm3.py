#!/usr/bin/env python3
"""
autophagy_dm3.py
================
Simulation and figure generator for:

  "Self-Regulation — Autophagy and the Triple-Alpha Process
   as dm³ Generative Transitions"
  Chapter A of Principia Orthogona, Book 3: The Mini-Beast
  Pablo Nogueira Grossi, G6 LLC (2026)
  Zenodo: https://doi.org/10.5281/zenodo.20168812

Figures produced
----------------
  fig_A1_t40_fold.pdf        — Triple-alpha T^40 reaction rate fold
  fig_A2_phase_portrait.pdf  — dm³ phase portrait, both systems superimposed
  fig_A3_whitney_potential.pdf — Whitney A₁ fold potential V(q) = q³ − 3q
  fig_A4_coherence_bridge.pdf — Parameter table as a visual chart
  coherence_bridge.csv        — Raw data for fig_A4

Lean 4 correspondence
---------------------
  fig_A1: Fold fires at V_critical_at_one (q=1, V'=0)
  fig_A2: Basin bounds from gronwall_radius (ε₀=1/3) and basin_asymmetry (r*≈4/5)
  fig_A3: V_factored: V(q)+2 = (q−1)²(q+2), V_at_one: V(1)=−2, mu_dm3: μ=−2
  fig_A4: mu_dm3_neg: −2 < 0 confirmed for each domain row

Author
------
  Pablo Nogueira Grossi | ORCID: 0009-0000-6496-2186
  G6 LLC, Newark NJ | pablogrossi@hotmail.com
  GitHub: https://github.com/TOTOGT/AXLE

License: MIT
"""
from __future__ import annotations
import argparse
import csv
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.gridspec import GridSpec

# ── house style ──────────────────────────────────────────────────────────────
NAVY   = "#1a2744"
GOLD   = "#c9a84c"
CREAM  = "#faf7f0"
MID    = "#3a4f7a"
TEAL   = "#1a6b5a"
RED    = "#8a2a2a"
BLUE   = "#4a7fc0"
SMOKE  = "#f0ece4"

plt.rcParams.update({
    "font.family": "serif",
    "axes.facecolor": "#0d1117",
    "figure.facecolor": "#0d1117",
    "text.color": "#e6edf3",
    "axes.labelcolor": "#e6edf3",
    "xtick.color": "#8b949e",
    "ytick.color": "#8b949e",
    "axes.edgecolor": "#30363d",
    "grid.color": "#21262d",
    "grid.linewidth": 0.5,
    "axes.titlecolor": GOLD,
})


# ── Coherence Bridge data ────────────────────────────────────────────────────
BRIDGE_DATA = [
    ("HPA stress axis",       -0.38,  0.21,  1.9,  "0.15–0.22"),
    ("Neural oscillations",   -0.55,  0.45,  2.1,  "0.25–0.35"),
    ("Circadian clock",       -0.29,  2*np.pi/86400, 1.6, "0.08–0.12"),
    ("Wigner crystal",        -0.31,  0.19,  1.7,  "r*ₛ ≈ 30–40"),
    ("Tubulin/microtubule",   -0.48,  0.31,  2.0,  "GTP:GDP* ≈ 0.3"),
    ("Autophagy (cell) [A]",    -0.41,  0.22,  1.85, "ρ* ≈ 0.15–0.22"),
    ("Triple-alpha (star) [B]", -0.88,  1e-10, 2.3,  "T* ≈ 10⁸ K"),
]


# ── Figure A.1 — T^40 fold ───────────────────────────────────────────────────
def fig_a1_t40(out_dir: str) -> None:
    """
    Triple-alpha reaction rate ε₃α ∝ T^40 near threshold.
    Lean correspondence: V_critical_at_one — the fold fires at T/T*=1.
    """
    fig, ax = plt.subplots(figsize=(8, 4.5))
    fig.patch.set_facecolor("#0d1117")
    ax.set_facecolor("#0d1117")

    T = np.linspace(0.50, 1.45, 1000)
    # Normalise so rate(1) = 1
    rate = T**40 / 1.0**40

    # Clip for display
    rate_disp = np.clip(rate, 0, 3)

    ax.plot(T, rate_disp, color="#ff6b6b", lw=2.5, label=r"$\varepsilon_{3\alpha} \propto T^{40}$")

    # Fold line
    ax.axvline(1.0, color=GOLD, lw=1.5, ls="--", alpha=0.8, label=r"$T^*$ fold point")
    ax.axhline(1.0, color=GOLD, lw=0.8, ls=":", alpha=0.4)

    # Annotations
    ax.text(1.02, 2.6, "FOLD FIRES\n(supercritical)", color="#ff6b6b",
            fontsize=8, va="top", fontfamily="monospace")
    ax.text(0.78, 0.08, "subcritical\n≈ 0", color=BLUE,
            fontsize=8, va="bottom", fontfamily="monospace")

    # Gold dot at fold
    ax.scatter([1.0], [1.0], color=GOLD, s=60, zorder=5)
    ax.text(1.02, 0.85, r"$q^*=1$, $V(1)=-2$", color=GOLD,
            fontsize=8, fontfamily="monospace")

    ax.set_xlabel(r"$T / T^*$ (normalised core temperature)", fontsize=10)
    ax.set_ylabel(r"Reaction rate (normalised)", fontsize=10)
    ax.set_title(
        "Figure A.1 — Triple-Alpha T⁴⁰ Fold\n"
        r"Whitney $A_1$ condition: $V'(1)=0$, $V''(1)\neq 0$ "
        "(verified: V_critical_at_one, V_second_deriv_ne_zero)",
        fontsize=9, pad=10,
    )
    ax.set_xlim(0.50, 1.45)
    ax.set_ylim(-0.05, 3.0)
    ax.legend(fontsize=9, facecolor="#161b22", edgecolor="#30363d",
              labelcolor="#e6edf3")
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    path = os.path.join(out_dir, "fig_A1_t40_fold.pdf")
    plt.savefig(path, dpi=150, bbox_inches="tight",
                facecolor="#0d1117", edgecolor="none")
    plt.close()
    print(f"Saved {path}")


# ── Figure A.2 — dm³ phase portrait ─────────────────────────────────────────
def fig_a2_phase(out_dir: str) -> None:
    """
    Contact normal form (ρ, θ) phase portrait.
    Gold circle = attractor Γ at r=1.
    Dashed circles = Gronwall bound ε₀=1/3 and inner boundary r*=4/5.
    Lean: gronwall_radius (1/3), basin_asymmetry (1/3 < 4/5).
    """
    fig, axes = plt.subplots(1, 2, figsize=(11, 5))
    fig.patch.set_facecolor("#0d1117")

    labels = [
        ("AUTOPHAGY — $X_{\\mathrm{auto}}$",
         r"$\rho$ = mTORC1 activity · $\theta$ = autophagic phase"),
        ("TRIPLE-ALPHA — $X_{\\mathrm{star}}$",
         r"$\rho$ = $T/T^*$ · $\theta$ = pulsation phase"),
    ]

    rng = np.random.default_rng(42)

    for ax, (title, subtitle) in zip(axes, labels):
        ax.set_facecolor("#0d1117")
        ax.set_aspect("equal")
        ax.set_xlim(-2.4, 2.4)
        ax.set_ylim(-2.4, 2.4)

        # Reference circles
        theta = np.linspace(0, 2*np.pi, 300)
        for r, color, ls, lw, label in [
            (1/3, GOLD,  "--", 0.8, r"$\varepsilon_0=1/3$ (Gronwall)"),
            (4/5, GOLD,  ":", 1.0,  r"$r^*\approx 4/5$ (inner boundary)"),
            (1.0, GOLD,  "-",  2.2, r"$\Gamma$ (attractor, $r=1$)"),
            (1.5, MID,   "-",  0.4, ""),
        ]:
            ax.plot(r*np.cos(theta), r*np.sin(theta),
                    color=color, ls=ls, lw=lw,
                    label=label if label else None, alpha=0.85)

        # Converging orbits (blue) — start outside attractor
        for r0, th0 in [(1.6+i*0.07, j*np.pi/3) for i in range(4) for j in range(6)]:
            r, th = r0, th0
            xs, ys = [r*np.cos(th)], [r*np.sin(th)]
            for _ in range(180):
                dr = 0.015 * r * (1 - r*r)
                r  = max(0.02, r + dr)
                th = th + 0.18
                xs.append(r*np.cos(th)); ys.append(r*np.sin(th))
            ax.plot(xs, ys, color="#58a6ff", lw=0.8, alpha=0.55)

        # Escape orbits (red) — start inside inner boundary
        for r0, th0 in [(0.65+i*0.04, j*np.pi/3+0.5) for i in range(3) for j in range(6)]:
            r, th = r0, th0
            xs, ys = [r*np.cos(th)], [r*np.sin(th)]
            for _ in range(120):
                dr = -0.022 * r * (1 - r*r)
                r  = max(0.01, r + dr)
                th = th + 0.18
                xs.append(r*np.cos(th)); ys.append(r*np.sin(th))
            ax.plot(xs, ys, color="#ff6b6b", lw=0.8, alpha=0.50)

        ax.set_title(f"{title}\n{subtitle}", fontsize=8.5, pad=6)
        ax.set_xlabel(r"$\rho \cos\theta$", fontsize=9)
        ax.set_ylabel(r"$\rho \sin\theta$", fontsize=9)

    axes[0].legend(fontsize=7.5, loc="upper right",
                   facecolor="#161b22", edgecolor="#30363d",
                   labelcolor="#e6edf3")

    # Add shared legend note
    blue_p  = mpatches.Patch(color="#58a6ff", alpha=0.7, label="Converging (basin)")
    red_p   = mpatches.Patch(color="#ff6b6b", alpha=0.7, label="Escaping (outside r*)")
    axes[1].legend(handles=[blue_p, red_p], fontsize=7.5, loc="upper right",
                   facecolor="#161b22", edgecolor="#30363d",
                   labelcolor="#e6edf3")

    fig.suptitle(
        "Figure A.2 — dm³ Phase Portrait: Two Systems, One Attractor\n"
        "Lean: gronwall_radius (ε₀=1/3), basin_asymmetry (1/3 < 4/5)",
        fontsize=9, y=1.01,
    )
    plt.tight_layout()
    path = os.path.join(out_dir, "fig_A2_phase_portrait.pdf")
    plt.savefig(path, dpi=150, bbox_inches="tight",
                facecolor="#0d1117", edgecolor="none")
    plt.close()
    print(f"Saved {path}")


# ── Figure A.3 — Whitney A₁ fold potential ───────────────────────────────────
def fig_a3_whitney(out_dir: str) -> None:
    """
    V(q) = q³ − 3q. Double root factorisation V(q)+2 = (q−1)²(q+2).
    Lean: V_factored, V_at_one (V(1)=−2), mu_canonical (−V''(1)/2=−3), mu_dm3 (−2).
    """
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    fig.patch.set_facecolor("#0d1117")

    q = np.linspace(-1.3, 2.3, 800)
    V = q**3 - 3*q
    Vfact = (q - 1)**2 * (q + 2) - 2   # = V(q), factored form

    # Left: V(q) with annotations
    ax = axes[0]
    ax.set_facecolor("#0d1117")
    ax.axhline(0, color="#30363d", lw=0.6)
    ax.axvline(0, color="#30363d", lw=0.6)
    ax.axhline(-2, color=GOLD, lw=0.8, ls="--", alpha=0.5, label="V = −2")
    ax.axvline(1, color=GOLD, lw=0.8, ls="--", alpha=0.5, label="q = 1 (fold)")

    ax.plot(q, V, color="#58a6ff", lw=2.5, label=r"$V(q)=q^3-3q$")
    ax.plot(q, Vfact, color="#3fb950", lw=1.5, ls="--",
            label=r"$(q-1)^2(q+2)-2$  (factored)", alpha=0.8)

    ax.scatter([1], [-2], color=GOLD, s=80, zorder=5)
    ax.annotate(r"$q=1$, $V(1)=-2$, double root $\to$ $\mu=-2$",
                xy=(1, -2), xytext=(1.35, -0.3),
                color=GOLD, fontsize=8, fontfamily="monospace",
                arrowprops=dict(arrowstyle="->", color=GOLD, lw=1))

    ax.set_xlim(-1.3, 2.3)
    ax.set_ylim(-4.5, 3.5)
    ax.set_xlabel("$q$ (normalised order parameter)", fontsize=9)
    ax.set_ylabel("$V(q)$", fontsize=9)
    ax.set_title(
        "Whitney A₁ Fold Potential\n"
        r"$V(q) = q^3 - 3q$, double root at $q^*=1$",
        fontsize=9,
    )
    ax.legend(fontsize=8, facecolor="#161b22", edgecolor="#30363d",
              labelcolor="#e6edf3")
    ax.grid(True, alpha=0.25)

    # Right: V'(q) and V''(q) to show A₁ conditions
    ax2 = axes[1]
    ax2.set_facecolor("#0d1117")
    Vp  = 3*q**2 - 3           # V'
    Vpp = 6*q                  # V''
    ax2.axhline(0, color="#30363d", lw=0.6)
    ax2.axvline(1, color=GOLD, lw=0.8, ls="--", alpha=0.5)

    ax2.plot(q, Vp,  color="#ff7b72", lw=2, label=r"$V'(q) = 3q^2-3$")
    ax2.plot(q, Vpp, color="#ffa657", lw=2, label=r"$V''(q) = 6q$")

    ax2.scatter([1], [0], color="#ff7b72", s=80, zorder=5)
    ax2.annotate(r"$V'(1)=0$ ✓", xy=(1, 0), xytext=(1.3, 1.5),
                 color="#ff7b72", fontsize=8, fontfamily="monospace",
                 arrowprops=dict(arrowstyle="->", color="#ff7b72", lw=1))
    ax2.scatter([1], [6], color="#ffa657", s=80, zorder=5)
    ax2.annotate(r"$V''(1)=6\neq0$ ✓", xy=(1, 6), xytext=(-0.8, 7),
                 color="#ffa657", fontsize=8, fontfamily="monospace",
                 arrowprops=dict(arrowstyle="->", color="#ffa657", lw=1))

    ax2.set_xlim(-1.3, 2.3)
    ax2.set_ylim(-10, 12)
    ax2.set_xlabel("$q$", fontsize=9)
    ax2.set_title(
        r"Whitney $A_1$ Conditions Verified"+"\n"
        r"$V'(1)=0$ (critical), $V''(1)\neq 0$ (non-degenerate)",
        fontsize=9,
    )
    ax2.legend(fontsize=8, facecolor="#161b22", edgecolor="#30363d",
               labelcolor="#e6edf3")
    ax2.grid(True, alpha=0.25)

    fig.suptitle(
        "Figure A.3 — Whitney A₁ Fold Potential V(q) = q³ − 3q\n"
        "Lean: V_factored, V_at_one, V_critical_at_one, V_second_deriv_ne_zero, mu_canonical",
        fontsize=9, y=1.01,
    )
    plt.tight_layout()
    path = os.path.join(out_dir, "fig_A3_whitney_potential.pdf")
    plt.savefig(path, dpi=150, bbox_inches="tight",
                facecolor="#0d1117", edgecolor="none")
    plt.close()
    print(f"Saved {path}")


# ── Figure A.4 — Coherence Bridge parameter chart ────────────────────────────
def fig_a4_coherence(out_dir: str) -> None:
    """
    Visual chart of the Coherence Bridge parameter table.
    Lean: mu_dm3_neg (μ_max < 0 for all rows).
    """
    domains = [d[0] for d in BRIDGE_DATA]
    mu      = [d[1] for d in BRIDGE_DATA]
    beta    = [d[3] for d in BRIDGE_DATA]

    colors = [MID]*5 + [GOLD, TEAL]   # last two are new rows

    fig = plt.figure(figsize=(12, 5))
    fig.patch.set_facecolor("#0d1117")
    gs = GridSpec(1, 2, figure=fig, wspace=0.35)

    # μ_max bar chart
    ax1 = fig.add_subplot(gs[0])
    ax1.set_facecolor("#0d1117")
    bars = ax1.barh(domains, mu, color=colors, edgecolor="#30363d",
                    height=0.6)
    ax1.axvline(0, color="#30363d", lw=0.8)
    ax1.set_xlabel(r"$\mu_{\max}$ (s⁻¹)", fontsize=10)
    ax1.set_title(
        r"Transverse Lyapunov exponent $\mu_{\max}$"+"\n"
        "Lean: mu_dm3_neg (all < 0)",
        fontsize=9,
    )
    ax1.tick_params(labelsize=8)
    for bar, val in zip(bars, mu):
        ax1.text(val - 0.01, bar.get_y() + bar.get_height()/2,
                 f"{val:.2f}", va="center", ha="right",
                 fontsize=7.5, color=CREAM, fontfamily="monospace")

    # β exponent dot plot
    ax2 = fig.add_subplot(gs[1])
    ax2.set_facecolor("#0d1117")
    y_pos = range(len(domains))
    ax2.scatter(beta, y_pos, color=colors, s=80, zorder=5)
    ax2.axvline(2.0, color=GOLD, lw=0.8, ls="--", alpha=0.5, label="β = 2.0")
    for i, (b, d) in enumerate(zip(beta, domains)):
        ax2.text(b + 0.03, i, f"{b}", va="center", fontsize=7.5,
                 color=CREAM, fontfamily="monospace")
    ax2.set_yticks(list(y_pos))
    ax2.set_yticklabels(domains, fontsize=8)
    ax2.set_xlabel("β (fold sharpness exponent)", fontsize=10)
    ax2.set_title("Fold sharpness β\nHigher β = sharper transition", fontsize=9)
    ax2.set_xlim(1.3, 2.7)
    ax2.legend(fontsize=8, facecolor="#161b22", edgecolor="#30363d",
               labelcolor="#e6edf3")

    # Legend patches
    old_p = mpatches.Patch(color=MID, label="Prior Coherence Bridge rows")
    new_a = mpatches.Patch(color=GOLD, label="[A] Autophagy (Chapter A, new)")
    new_s = mpatches.Patch(color=TEAL, label="[B] Triple-alpha (Chapter A, new)")
    fig.legend(handles=[old_p, new_a, new_s], fontsize=8, loc="lower center",
               ncol=3, bbox_to_anchor=(0.5, -0.06),
               facecolor="#161b22", edgecolor="#30363d", labelcolor="#e6edf3")

    fig.suptitle(
        "Figure A.4 — Coherence Bridge: Two New Domains (Chapter A)\n"
        "All μ_max < 0 (verified: mu_dm3_neg in AutophagyDm3.lean)",
        fontsize=10, y=1.02,
    )
    plt.tight_layout()
    path = os.path.join(out_dir, "fig_A4_coherence_bridge.pdf")
    plt.savefig(path, dpi=150, bbox_inches="tight",
                facecolor="#0d1117", edgecolor="none")
    plt.close()
    print(f"Saved {path}")


# ── CSV data ──────────────────────────────────────────────────────────────────
def write_csv(out_dir: str) -> None:
    path = os.path.join(out_dir, "coherence_bridge.csv")
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=[
            "domain", "mu_max_per_s", "omega_rad_per_s", "beta", "kappa_star"])
        w.writeheader()
        for row in BRIDGE_DATA:
            w.writerow({
                "domain":         row[0],
                "mu_max_per_s":   row[1],
                "omega_rad_per_s": row[2],
                "beta":           row[3],
                "kappa_star":     row[4],
            })
    print(f"Saved {path}")


# ── Entry point ───────────────────────────────────────────────────────────────
def main() -> None:
    ap = argparse.ArgumentParser(
        description="Generate all figures for the Autophagy/Triple-Alpha chapter."
    )
    ap.add_argument("--out", default="figures",
                    help="Output directory (default: ./figures)")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    print("Generating figures for Chapter A — Self-Regulation...")
    fig_a1_t40(args.out)
    fig_a2_phase(args.out)
    fig_a3_whitney(args.out)
    fig_a4_coherence(args.out)
    write_csv(args.out)
    print(f"\nAll outputs written to ./{args.out}/")


if __name__ == "__main__":
    main()
