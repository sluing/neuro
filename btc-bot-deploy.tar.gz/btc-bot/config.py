"""
BTC Bot Configuration
Fill in your values before deploying.
Never commit this file to GitHub.
"""

# ── Binance.US ────────────────────────────────────────────────
BINANCE_API_KEY    = "YOUR_BINANCE_US_API_KEY"
BINANCE_SECRET     = "YOUR_BINANCE_US_SECRET"
BINANCE_BASE_URL   = "https://api.binance.us"
TRADING_PAIR       = "BTCUSDT"

# ── Coinbase Advanced Trade (CDP key) ─────────────────────────
COINBASE_API_KEY   = "YOUR_COINBASE_CDP_API_KEY"
COINBASE_SECRET    = "YOUR_COINBASE_CDP_SECRET"  # full PEM string or path

# ── Bitkey self-custody address ───────────────────────────────
# Copy once from Bitkey app → Receive → Another exchange or wallet
BITKEY_BTC_ADDRESS = "YOUR_BITKEY_RECEIVE_ADDRESS"

# ── Capital allocation ────────────────────────────────────────
BOT1_CAPITAL_USD   = 600    # Signal bot allocation
BOT2_CAPITAL_USD   = 600    # Grid bot allocation
RESERVE_USD        = 300    # Never traded — emergency buffer

# ── Risk controls ─────────────────────────────────────────────
STOP_LOSS_PCT           = 0.03   # 3% stop loss per trade
DAILY_DRAWDOWN_LIMIT    = 0.05   # pause all bots if account drops 5% today
MAX_POSITION_SIZE_USD   = 200    # max single order size

# ── Profit sweep thresholds ───────────────────────────────────
PROFIT_SWEEP_USD        = 50     # sweep USD profit to Coinbase at $50
BTC_WITHDRAWAL_USD      = 200    # withdraw BTC to Bitkey when worth $200+

# ── Bot 2 Grid settings ───────────────────────────────────────
GRID_LEVELS            = 10     # number of grid levels
GRID_RANGE_PCT         = 0.04   # 4% price range above and below current price

# ── Bot 1 Signal settings ─────────────────────────────────────
EMA_FAST               = 9      # fast EMA period
EMA_SLOW               = 21     # slow EMA period
RSI_PERIOD             = 14
RSI_OVERBOUGHT         = 70
RSI_OVERSOLD           = 30
CANDLE_INTERVAL        = "5m"   # 5-minute candles

# ── Logging ───────────────────────────────────────────────────
LOG_DIR                = "logs"
LOG_LEVEL              = "INFO"

# ── Sweep schedule ────────────────────────────────────────────
SWEEP_CHECK_INTERVAL   = 300    # check every 5 minutes
