"""
Connection test — run this before starting bots.
Verifies all API connections without placing any orders.

Usage: python test_connection.py
"""

import sys
import logging
logging.basicConfig(level=logging.INFO, format="%(levelname)s — %(message)s")
logger = logging.getLogger("test")


def test_binance():
    print("\n── Binance.US ──────────────────────────────────")
    try:
        from engine.exchange import BinanceClient
        client = BinanceClient()

        price = client.get_price()
        assert price and price > 0, "Could not get BTC price"
        print(f"  ✓ Connected — BTC price: ${price:,.2f}")

        balance = client.get_usdt_balance()
        print(f"  ✓ USD balance: ${balance:.2f}")

        btc = client.get_btc_balance()
        print(f"  ✓ BTC balance: {btc:.8f}")

        candles = client.get_candles(limit=10)
        assert len(candles) > 0, "No candles returned"
        print(f"  ✓ Market data: {len(candles)} candles received")

        orders = client.get_open_orders()
        print(f"  ✓ Open orders: {len(orders)}")

        return True
    except Exception as e:
        print(f"  ✗ FAILED: {e}")
        return False


def test_coinbase():
    print("\n── Coinbase ────────────────────────────────────")
    try:
        from sweep.sweep_engine import SweepEngine
        from engine.exchange import BinanceClient
        sweep = SweepEngine(BinanceClient())

        accounts = sweep._get_cb_accounts()
        assert accounts, "No accounts returned — check CDP API key"
        print(f"  ✓ Connected — {len(accounts)} accounts found")

        usd = sweep._get_cb_usd_balance()
        print(f"  ✓ USD balance: ${usd:.2f}")

        btc = sweep._get_cb_btc_balance()
        print(f"  ✓ BTC balance: {btc:.8f}")

        return True
    except Exception as e:
        print(f"  ✗ FAILED: {e}")
        return False


def test_config():
    print("\n── Config ──────────────────────────────────────")
    try:
        from config import (
            BINANCE_API_KEY, BINANCE_SECRET,
            COINBASE_API_KEY, COINBASE_SECRET,
            BITKEY_BTC_ADDRESS
        )

        checks = [
            ("Binance API key",    BINANCE_API_KEY,    "YOUR_BINANCE"),
            ("Binance secret",     BINANCE_SECRET,     "YOUR_BINANCE"),
            ("Coinbase API key",   COINBASE_API_KEY,   "YOUR_COINBASE"),
            ("Coinbase secret",    COINBASE_SECRET,    "YOUR_COINBASE"),
            ("Bitkey address",     BITKEY_BTC_ADDRESS, "YOUR_BITKEY"),
        ]

        all_ok = True
        for name, value, placeholder in checks:
            if placeholder in str(value):
                print(f"  ✗ {name}: NOT SET (still placeholder)")
                all_ok = False
            else:
                masked = str(value)[:6] + "..." + str(value)[-4:]
                print(f"  ✓ {name}: {masked}")

        return all_ok
    except Exception as e:
        print(f"  ✗ Config error: {e}")
        return False


def main():
    print("=" * 50)
    print("  BTC Bot — Connection Test")
    print("=" * 50)

    config_ok   = test_config()
    binance_ok  = test_binance() if config_ok else False
    coinbase_ok = test_coinbase() if config_ok else False

    print("\n── Results ─────────────────────────────────────")
    print(f"  Config:   {'✓ OK' if config_ok else '✗ FAIL'}")
    print(f"  Binance:  {'✓ OK' if binance_ok else '✗ FAIL'}")
    print(f"  Coinbase: {'✓ OK' if coinbase_ok else '✗ FAIL'}")

    if config_ok and binance_ok and coinbase_ok:
        print("\n  ✓ All systems ready — run: python main.py")
        sys.exit(0)
    else:
        print("\n  ✗ Fix errors above before starting bots")
        sys.exit(1)


if __name__ == "__main__":
    main()
