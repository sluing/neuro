"""
Bot 1 — Signal Bot
Strategy: EMA 9/21 crossover + RSI filter
Buys when fast EMA crosses above slow EMA and RSI < 70
Sells when fast EMA crosses below slow EMA or stop-loss hit
"""

import time
import logging
from engine.exchange import BinanceClient
from engine.risk import RiskEngine
from engine.indicators import ema_crossover_signal, rsi
from config import (
    BOT1_CAPITAL_USD, CANDLE_INTERVAL,
    EMA_FAST, EMA_SLOW, RSI_PERIOD,
    RSI_OVERBOUGHT, RSI_OVERSOLD,
    STOP_LOSS_PCT
)

logger = logging.getLogger("bot1_signal")


class SignalBot:

    def __init__(self, client: BinanceClient, risk: RiskEngine):
        self.client      = client
        self.risk        = risk
        self.position    = None   # {"entry_price": float, "btc_qty": float}
        self.capital     = BOT1_CAPITAL_USD
        self.name        = "Bot1-Signal"

    def _get_signal(self):
        candles = self.client.get_candles(CANDLE_INTERVAL, limit=100)
        if not candles:
            return "HOLD", 50.0
        closes  = [c["close"] for c in candles]
        signal  = ema_crossover_signal(candles, EMA_FAST, EMA_SLOW)
        rsi_val = rsi(closes, RSI_PERIOD)
        return signal, rsi_val

    def _open_position(self, price: float):
        usd_to_use = min(self.capital * 0.95, BOT1_CAPITAL_USD)
        result = self.client.buy_market(usd_to_use)
        if result and result.get("status") == "FILLED":
            filled_qty   = float(result.get("executedQty", 0))
            filled_price = float(result.get("cummulativeQuoteQty", 0)) / filled_qty if filled_qty else price
            self.position = {
                "entry_price": filled_price,
                "btc_qty":     filled_qty,
                "usd_spent":   float(result.get("cummulativeQuoteQty", usd_to_use))
            }
            self.risk.log_trade(self.name, "BUY", filled_price, usd_to_use, result)
            logger.info(f"Position opened: {filled_qty:.8f} BTC @ ${filled_price:.2f}")
        else:
            logger.error(f"Buy order failed: {result}")

    def _close_position(self, reason: str):
        if not self.position:
            return
        result = self.client.sell_market(self.position["btc_qty"])
        if result:
            sell_qty   = float(result.get("executedQty", self.position["btc_qty"]))
            sell_total = float(result.get("cummulativeQuoteQty", 0))
            profit     = sell_total - self.position["usd_spent"]
            self.risk.log_trade(
                self.name, f"SELL({reason})",
                sell_total / sell_qty if sell_qty else 0,
                sell_total, result
            )
            logger.info(
                f"Position closed [{reason}]: "
                f"profit=${profit:.2f} | "
                f"entry=${self.position['entry_price']:.2f}"
            )
            self.position = None
        else:
            logger.error("Sell order failed")

    def tick(self):
        if not self.risk.is_safe_to_trade():
            return

        price = self.client.get_price()
        if not price:
            return

        signal, rsi_val = self._get_signal()

        # Check stop-loss on open position
        if self.position:
            if self.risk.check_position_stop_loss(
                self.position["entry_price"], price, "BUY"
            ):
                self._close_position("stop-loss")
                return

        # Entry signal
        if signal == "BUY" and rsi_val < RSI_OVERBOUGHT and not self.position:
            logger.info(f"BUY signal — RSI: {rsi_val:.1f}, price: ${price:.2f}")
            self._open_position(price)

        # Exit signal
        elif signal == "SELL" and self.position:
            logger.info(f"SELL signal — RSI: {rsi_val:.1f}, price: ${price:.2f}")
            self._close_position("signal")

    def run(self, interval_seconds: int = 60):
        logger.info(f"{self.name} started — capital: ${self.capital}")
        while True:
            try:
                self.tick()
            except Exception as e:
                logger.error(f"{self.name} tick error: {e}")
            time.sleep(interval_seconds)
