"""
Bot 2 — Grid Bot
Strategy: Place buy/sell limit orders at fixed price intervals
Profits from BTC oscillating within a price range.
Automatically rebuilds grid when price moves out of range.
"""

import time
import logging
from engine.exchange import BinanceClient
from engine.risk import RiskEngine
from config import (
    BOT2_CAPITAL_USD, GRID_LEVELS, GRID_RANGE_PCT,
    MAX_POSITION_SIZE_USD
)

logger = logging.getLogger("bot2_grid")


class GridBot:

    def __init__(self, client: BinanceClient, risk: RiskEngine):
        self.client      = client
        self.risk        = risk
        self.capital     = BOT2_CAPITAL_USD
        self.name        = "Bot2-Grid"
        self.grid_orders = []   # list of active order ids
        self.grid_center = None
        self.grid_low    = None
        self.grid_high   = None

    def _build_grid(self, center_price: float):
        """Cancel existing grid and place new one around center price."""
        logger.info(f"Building grid around ${center_price:.2f}")

        # Cancel all existing grid orders
        for order_id in self.grid_orders:
            try:
                self.client.cancel_order(order_id)
            except Exception:
                pass
        self.grid_orders = []

        low  = center_price * (1 - GRID_RANGE_PCT)
        high = center_price * (1 + GRID_RANGE_PCT)
        step = (high - low) / GRID_LEVELS

        # Capital per grid level
        usd_per_level = (self.capital * 0.9) / GRID_LEVELS

        self.grid_center = center_price
        self.grid_low    = low
        self.grid_high   = high

        placed = 0
        for i in range(GRID_LEVELS):
            level_price = low + (i * step)

            if level_price < center_price:
                # Buy orders below center
                result = self.client.buy_limit(level_price, usd_per_level)
            else:
                # Sell orders above center — need BTC to sell
                btc_qty = usd_per_level / level_price
                result = self.client.sell_limit(level_price, btc_qty)

            if result and "orderId" in result:
                self.grid_orders.append(result["orderId"])
                placed += 1

        logger.info(
            f"Grid built: {placed} orders | "
            f"range ${low:.0f}–${high:.0f} | "
            f"step ${step:.0f}"
        )

    def _grid_needs_rebuild(self, current_price: float) -> bool:
        if not self.grid_center:
            return True
        # Rebuild if price moves outside grid range
        return (
            current_price < self.grid_low * 0.99 or
            current_price > self.grid_high * 1.01
        )

    def _count_active_orders(self) -> int:
        open_orders = self.client.get_open_orders()
        active_ids  = {o["orderId"] for o in open_orders}
        self.grid_orders = [oid for oid in self.grid_orders if oid in active_ids]
        return len(self.grid_orders)

    def tick(self):
        if not self.risk.is_safe_to_trade():
            return

        price = self.client.get_price()
        if not price:
            return

        if self._grid_needs_rebuild(price):
            self._build_grid(price)
            return

        active = self._count_active_orders()
        expected = GRID_LEVELS

        # If more than 2 orders filled, rebuild grid at new center
        if active < expected - 2:
            logger.info(
                f"Grid drift: {active}/{expected} orders active — rebuilding"
            )
            self._build_grid(price)

    def run(self, interval_seconds: int = 30):
        logger.info(f"{self.name} started — capital: ${self.capital}")
        while True:
            try:
                self.tick()
            except Exception as e:
                logger.error(f"{self.name} tick error: {e}")
            time.sleep(interval_seconds)
