"""
Profit sweep engine
Flow: Binance.US profit (USD) → Coinbase (buy BTC) → Bitkey address
Runs as a separate thread, checks every 5 minutes.
"""

import time
import logging
import jwt
import uuid
import requests
from datetime import datetime, timezone
from cryptography.hazmat.primitives.serialization import load_pem_private_key
from config import (
    COINBASE_API_KEY, COINBASE_SECRET,
    BITKEY_BTC_ADDRESS,
    PROFIT_SWEEP_USD, BTC_WITHDRAWAL_USD,
    BOT1_CAPITAL_USD, BOT2_CAPITAL_USD, RESERVE_USD,
    SWEEP_CHECK_INTERVAL
)

logger = logging.getLogger("sweep")

COINBASE_BASE = "https://api.coinbase.com"


class SweepEngine:

    def __init__(self, binance_client):
        self.binance      = binance_client
        self.baseline_usd = BOT1_CAPITAL_USD + BOT2_CAPITAL_USD + RESERVE_USD
        self._cb_key      = COINBASE_API_KEY
        self._cb_secret   = COINBASE_SECRET

    # ── Coinbase JWT auth ─────────────────────────────────────

    def _cb_headers(self, method: str, path: str) -> dict:
        """Generate Coinbase CDP JWT auth headers."""
        try:
            secret = self._cb_secret
            if isinstance(secret, str):
                secret = secret.encode()
            private_key = load_pem_private_key(secret, password=None)
        except Exception as e:
            logger.error(f"Coinbase key load error: {e}")
            return {}

        now = int(datetime.now(timezone.utc).timestamp())
        payload = {
            "sub":  self._cb_key,
            "iss":  "cdp",
            "nbf":  now,
            "exp":  now + 120,
            "uri":  f"{method} api.coinbase.com{path}",
        }
        token = jwt.encode(
            payload,
            private_key,
            algorithm="ES256",
            headers={"kid": self._cb_key, "nonce": str(uuid.uuid4())}
        )
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type":  "application/json"
        }

    def _cb_get(self, path: str) -> dict:
        headers = self._cb_headers("GET", path)
        try:
            r = requests.get(f"{COINBASE_BASE}{path}", headers=headers, timeout=10)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            logger.error(f"Coinbase GET {path}: {e}")
            return {}

    def _cb_post(self, path: str, body: dict) -> dict:
        headers = self._cb_headers("POST", path)
        try:
            r = requests.post(
                f"{COINBASE_BASE}{path}",
                headers=headers,
                json=body,
                timeout=10
            )
            r.raise_for_status()
            return r.json()
        except Exception as e:
            logger.error(f"Coinbase POST {path}: {e}")
            return {}

    # ── Coinbase operations ───────────────────────────────────

    def _get_cb_accounts(self) -> list:
        data = self._cb_get("/api/v3/brokerage/accounts")
        return data.get("accounts", [])

    def _get_cb_btc_balance(self) -> float:
        accounts = self._get_cb_accounts()
        for a in accounts:
            if a.get("currency") == "BTC":
                return float(a.get("available_balance", {}).get("value", 0))
        return 0.0

    def _get_cb_usd_balance(self) -> float:
        accounts = self._get_cb_accounts()
        for a in accounts:
            if a.get("currency") in ("USD", "USDC"):
                return float(a.get("available_balance", {}).get("value", 0))
        return 0.0

    def _buy_btc_on_coinbase(self, usd_amount: float) -> bool:
        """Buy BTC on Coinbase with USD profit."""
        logger.info(f"Buying BTC on Coinbase with ${usd_amount:.2f}")
        result = self._cb_post("/api/v3/brokerage/orders", {
            "client_order_id": str(uuid.uuid4()),
            "product_id":      "BTC-USD",
            "side":            "BUY",
            "order_configuration": {
                "market_market_ioc": {
                    "quote_size": str(round(usd_amount, 2))
                }
            }
        })
        success = result.get("success", False)
        if success:
            logger.info(f"Coinbase BTC buy successful: ${usd_amount:.2f}")
        else:
            logger.error(f"Coinbase BTC buy failed: {result}")
        return success

    def _withdraw_btc_to_bitkey(self, btc_amount: float) -> bool:
        """Withdraw BTC from Coinbase to Bitkey address."""
        logger.info(
            f"Withdrawing {btc_amount:.8f} BTC to Bitkey: {BITKEY_BTC_ADDRESS}"
        )
        # Get BTC account UUID
        accounts = self._get_cb_accounts()
        btc_account_id = None
        for a in accounts:
            if a.get("currency") == "BTC":
                btc_account_id = a.get("uuid")
                break

        if not btc_account_id:
            logger.error("No BTC account found on Coinbase")
            return False

        result = self._cb_post(
            f"/v2/accounts/{btc_account_id}/transactions",
            {
                "type":     "send",
                "to":       BITKEY_BTC_ADDRESS,
                "amount":   str(round(btc_amount, 8)),
                "currency": "BTC",
                "description": "Auto-sweep to Bitkey"
            }
        )
        if result.get("data"):
            logger.info(f"BTC withdrawal to Bitkey confirmed")
            return True
        else:
            logger.error(f"BTC withdrawal failed: {result}")
            return False

    # ── Main sweep logic ──────────────────────────────────────

    def check_and_sweep(self):
        """
        1. Check Binance.US USD balance for profit above baseline
        2. If profit >= threshold → buy BTC on Coinbase
        3. If Coinbase BTC balance >= withdrawal threshold → send to Bitkey
        """
        try:
            # Step 1: Check for profit on Binance.US
            binance_usd = self.binance.get_usdt_balance()
            if binance_usd is None:
                return

            profit = binance_usd - self.baseline_usd
            logger.debug(
                f"Binance balance: ${binance_usd:.2f} | "
                f"baseline: ${self.baseline_usd:.2f} | "
                f"profit: ${profit:.2f}"
            )

            if profit >= PROFIT_SWEEP_USD:
                logger.info(f"Profit ${profit:.2f} reached sweep threshold")
                # Keep a buffer — only sweep 80% of profit
                sweep_amount = profit * 0.8
                if self._buy_btc_on_coinbase(sweep_amount):
                    logger.info(f"Swept ${sweep_amount:.2f} profit to Coinbase BTC")

            # Step 2: Check Coinbase BTC balance for withdrawal
            cb_btc = self._get_cb_btc_balance()
            if cb_btc > 0:
                # Get current BTC price estimate
                btc_price = self.binance.get_price() or 50000
                cb_btc_usd = cb_btc * btc_price

                logger.debug(
                    f"Coinbase BTC: {cb_btc:.8f} (~${cb_btc_usd:.2f})"
                )

                if cb_btc_usd >= BTC_WITHDRAWAL_USD:
                    # Keep small buffer for fees
                    withdraw_btc = cb_btc * 0.98
                    self._withdraw_btc_to_bitkey(withdraw_btc)

        except Exception as e:
            logger.error(f"Sweep error: {e}")

    def run(self):
        logger.info(
            f"Sweep engine started | "
            f"profit threshold: ${PROFIT_SWEEP_USD} | "
            f"BTC withdrawal: ${BTC_WITHDRAWAL_USD}"
        )
        while True:
            self.check_and_sweep()
            time.sleep(SWEEP_CHECK_INTERVAL)
