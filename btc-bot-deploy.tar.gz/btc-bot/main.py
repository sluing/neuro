"""
Main entry point — launches all bots and sweep engine as threads.
Run with: python main.py

To stop cleanly: Ctrl+C
Kill switch resets in config or via: python main.py --reset-kill
"""

import sys
import logging
import threading
import os
import time
from datetime import datetime

# ── Setup logging ─────────────────────────────────────────────
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    handlers=[
        logging.FileHandler(f"logs/bot_{datetime.now().strftime('%Y%m%d')}.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("main")

# ── Imports ───────────────────────────────────────────────────
from engine.exchange import BinanceClient
from engine.risk import RiskEngine
from bots.bot1_signal import SignalBot
from bots.bot2_grid import GridBot
from sweep.sweep_engine import SweepEngine


def main():
    # Handle --reset-kill flag
    if "--reset-kill" in sys.argv:
        client = BinanceClient()
        risk   = RiskEngine(client)
        risk.reset_kill_switch()
        print("Kill switch reset. Run python main.py to restart bots.")
        return

    logger.info("=" * 60)
    logger.info("BTC BOT STARTING")
    logger.info("=" * 60)

    # ── Initialise shared components ──────────────────────────
    client = BinanceClient()
    risk   = RiskEngine(client)

    # Verify exchange connectivity
    price = client.get_price()
    if not price:
        logger.critical("Cannot connect to Binance.US — check API key and network")
        sys.exit(1)
    logger.info(f"Connected to Binance.US — BTC price: ${price:,.2f}")

    balance = client.get_usdt_balance()
    logger.info(f"Account USD balance: ${balance:.2f}")

    # ── Initialise bots ───────────────────────────────────────
    bot1 = SignalBot(client, risk)
    bot2 = GridBot(client, risk)
    sweep = SweepEngine(client)

    # ── Launch threads ────────────────────────────────────────
    threads = [
        threading.Thread(target=bot1.run,   args=(60,),  name="Bot1-Signal", daemon=True),
        threading.Thread(target=bot2.run,   args=(30,),  name="Bot2-Grid",   daemon=True),
        threading.Thread(target=sweep.run,               name="Sweep",       daemon=True),
    ]

    for t in threads:
        t.start()
        logger.info(f"Thread started: {t.name}")

    logger.info("All systems running. Press Ctrl+C to stop.")

    # ── Keep main thread alive + heartbeat ───────────────────
    try:
        while True:
            alive = [t.name for t in threads if t.is_alive()]
            dead  = [t.name for t in threads if not t.is_alive()]
            if dead:
                logger.error(f"Dead threads: {dead}")
            logger.info(
                f"Heartbeat — BTC: ${client.get_price():,.2f} | "
                f"Balance: ${client.get_usdt_balance():.2f} | "
                f"Threads: {alive}"
            )
            time.sleep(300)  # heartbeat every 5 minutes
    except KeyboardInterrupt:
        logger.info("Shutting down — cancelling all orders")
        client.cancel_all_orders()
        logger.info("Shutdown complete")


if __name__ == "__main__":
    main()
