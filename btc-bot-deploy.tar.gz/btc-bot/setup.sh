#!/bin/bash
# ─────────────────────────────────────────────────────────────
# BTC Bot — Vultr Ubuntu 22.04 setup
# Run once after spinning up your instance:
#   bash setup.sh
# ─────────────────────────────────────────────────────────────

set -e

echo "=================================================="
echo "  BTC Bot Setup — Vultr Ubuntu 22.04"
echo "=================================================="

# System update
echo "[1/6] Updating system..."
apt-get update -qq && apt-get upgrade -y -qq

# Python 3.11
echo "[2/6] Installing Python 3.11..."
apt-get install -y python3.11 python3.11-venv python3-pip -qq

# Create virtualenv
echo "[3/6] Creating virtual environment..."
python3.11 -m venv /opt/btcbot-env
source /opt/btcbot-env/bin/activate

# Install dependencies
echo "[4/6] Installing Python packages..."
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt

# Create log directory
mkdir -p logs

# Create systemd service for auto-restart
echo "[5/6] Creating systemd service..."
cat > /etc/systemd/system/btcbot.service << 'EOF'
[Unit]
Description=BTC Accumulation Bot
After=network.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/btc-bot
ExecStart=/opt/btcbot-env/bin/python main.py
Restart=on-failure
RestartSec=30
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable btcbot

echo "[6/6] Setup complete."
echo ""
echo "=================================================="
echo "  NEXT STEPS:"
echo "=================================================="
echo ""
echo "  1. Edit config.py — fill in your API keys:"
echo "     nano config.py"
echo ""
echo "  2. Test connection (dry run):"
echo "     source /opt/btcbot-env/bin/activate"
echo "     python test_connection.py"
echo ""
echo "  3. Start bots:"
echo "     systemctl start btcbot"
echo ""
echo "  4. Monitor:"
echo "     python dashboard.py"
echo "     journalctl -u btcbot -f"
echo ""
echo "  5. Stop bots:"
echo "     systemctl stop btcbot"
echo ""
echo "=================================================="
