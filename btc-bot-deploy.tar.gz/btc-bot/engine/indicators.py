"""
Technical indicators — EMA, RSI.
Pure functions, no side effects.
"""


def ema(prices: list, period: int) -> list:
    if len(prices) < period:
        return []
    k = 2 / (period + 1)
    result = [sum(prices[:period]) / period]
    for p in prices[period:]:
        result.append(p * k + result[-1] * (1 - k))
    return result


def rsi(prices: list, period: int = 14) -> float:
    if len(prices) < period + 1:
        return 50.0
    deltas = [prices[i] - prices[i-1] for i in range(1, len(prices))]
    gains  = [d for d in deltas if d > 0]
    losses = [-d for d in deltas if d < 0]

    avg_gain = sum(gains[-period:]) / period if gains else 0
    avg_loss = sum(losses[-period:]) / period if losses else 0.0001

    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))


def ema_crossover_signal(candles: list, fast: int, slow: int) -> str:
    """
    Returns 'BUY', 'SELL', or 'HOLD'
    based on EMA crossover.
    """
    closes = [c["close"] for c in candles]
    if len(closes) < slow + 2:
        return "HOLD"

    fast_ema = ema(closes, fast)
    slow_ema = ema(closes, slow)

    if len(fast_ema) < 2 or len(slow_ema) < 2:
        return "HOLD"

    # Align lengths
    min_len = min(len(fast_ema), len(slow_ema))
    f = fast_ema[-min_len:]
    s = slow_ema[-min_len:]

    prev_above = f[-2] > s[-2]
    curr_above = f[-1] > s[-1]

    if not prev_above and curr_above:
        return "BUY"
    if prev_above and not curr_above:
        return "SELL"
    return "HOLD"
