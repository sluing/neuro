"""
Risk engine — stop-loss, daily drawdown, kill switch.
Every trade goes through here before execution.
"""

import logging
import json
import os
from datetime import datetime, date
from config import (
    STOP_LOSS_PCT, DAILY_DRAWDOWN_LIMIT,
    BOT1_CAPITAL_USD, BOT2_CAPITAL_USD, LOG_DIR
)

logger = logging.getLogger(__name__)
STATE_FILE = os.path.join(LOG_DIR, "risk_state.json")


class RiskEngine:

    def __init__(self, exchange_client):
        self.client       = exchange_client
        self.killed       = False
        self.daily_start  = None
        self.day_checked  = None
        self._load_state()

    def _load_state(self):
        if os.path.exists(STATE_FILE):
            with open(STATE_FILE) as f:
                s = json.load(f)
            self.daily_start = s.get("daily_start_balance")
            self.day_checked = s.get("day_checked")
            self.killed      = s.get("killed", False)
            logger.info(f"Risk state loaded — killed={self.killed}")

    def _save_state(self):
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(STATE_FILE, "w") as f:
            json.dump({
                "daily_start_balance": self.daily_start,
                "day_checked":         self.day_checked,
                "killed":              self.killed
            }, f, indent=2)

    def reset_kill_switch(self):
        """Manual reset — call this after reviewing logs."""
        self.killed = False
        self._save_state()
        logger.warning("Kill switch RESET manually")

    def kill(self, reason: str):
        self.killed = True
        self._save_state()
        logger.critical(f"KILL SWITCH TRIGGERED: {reason}")
        try:
            self.client.cancel_all_orders()
        except Exception as e:
            logger.error(f"Could not cancel orders on kill: {e}")

    def check_daily_drawdown(self) -> bool:
        """Returns True if safe to trade, False if limit breached."""
        today = str(date.today())
        balance = self.client.get_usdt_balance()
        if balance is None:
            return True  # network issue, don't kill

        # Reset daily start at beginning of each day
        if self.day_checked != today:
            self.daily_start  = balance
            self.day_checked  = today
            self._save_state()
            logger.info(f"New day — starting balance: ${balance:.2f}")
            return True

        if self.daily_start and self.daily_start > 0:
            drawdown = (self.daily_start - balance) / self.daily_start
            if drawdown >= DAILY_DRAWDOWN_LIMIT:
                self.kill(
                    f"Daily drawdown limit hit: "
                    f"${self.daily_start:.2f} → ${balance:.2f} "
                    f"({drawdown*100:.1f}%)"
                )
                return False
        return True

    def check_position_stop_loss(
        self, entry_price: float, current_price: float, side: str
    ) -> bool:
        """Returns True if stop-loss triggered."""
        if side == "BUY":
            loss_pct = (entry_price - current_price) / entry_price
        else:
            loss_pct = (current_price - entry_price) / entry_price

        if loss_pct >= STOP_LOSS_PCT:
            logger.warning(
                f"Stop-loss triggered — entry: ${entry_price:.2f}, "
                f"current: ${current_price:.2f}, loss: {loss_pct*100:.1f}%"
            )
            return True
        return False

    def is_safe_to_trade(self) -> bool:
        if self.killed:
            logger.warning("Bot is killed — not trading")
            return False
        return self.check_daily_drawdown()

    def log_trade(self, bot_name: str, side: str, price: float,
                  amount_usd: float, result: dict):
        os.makedirs(LOG_DIR, exist_ok=True)
        log_path = os.path.join(LOG_DIR, "trades.jsonl")
        entry = {
            "time":       datetime.utcnow().isoformat(),
            "bot":        bot_name,
            "side":       side,
            "price":      price,
            "amount_usd": amount_usd,
            "result":     result
        }
        with open(log_path, "a") as f:
            f.write(json.dumps(entry) + "\n")
        logger.info(f"[{bot_name}] {side} ${amount_usd:.2f} @ ${price:.2f}")
