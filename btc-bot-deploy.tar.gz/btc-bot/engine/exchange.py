"""
Binance.US exchange client
Handles authentication, orders, balances.
"""

import hmac
import hashlib
import time
import requests
import logging
from urllib.parse import urlencode
from config import (
    BINANCE_API_KEY, BINANCE_SECRET, BINANCE_BASE_URL,
    TRADING_PAIR, MAX_POSITION_SIZE_USD
)

logger = logging.getLogger(__name__)


class BinanceClient:

    def __init__(self):
        self.base   = BINANCE_BASE_URL
        self.key    = BINANCE_API_KEY
        self.secret = BINANCE_SECRET.encode()
        self.session = requests.Session()
        self.session.headers.update({"X-MBX-APIKEY": self.key})

    def _sign(self, params: dict) -> dict:
        params["timestamp"] = int(time.time() * 1000)
        query = urlencode(params)
        sig = hmac.new(self.secret, query.encode(), hashlib.sha256).hexdigest()
        params["signature"] = sig
        return params

    def _get(self, path, params=None, signed=False):
        params = params or {}
        if signed:
            params = self._sign(params)
        try:
            r = self.session.get(f"{self.base}{path}", params=params, timeout=10)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            logger.error(f"GET {path} failed: {e}")
            return None

    def _post(self, path, params=None):
        params = params or {}
        params = self._sign(params)
        try:
            r = self.session.post(f"{self.base}{path}", params=params, timeout=10)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            logger.error(f"POST {path} failed: {e}")
            return None

    def _delete(self, path, params=None):
        params = params or {}
        params = self._sign(params)
        try:
            r = self.session.delete(f"{self.base}{path}", params=params, timeout=10)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            logger.error(f"DELETE {path} failed: {e}")
            return None

    # ── Market data ──────────────────────────────────────────

    def get_price(self) -> float:
        data = self._get("/api/v3/ticker/price", {"symbol": TRADING_PAIR})
        return float(data["price"]) if data else None

    def get_candles(self, interval="5m", limit=100) -> list:
        data = self._get("/api/v3/klines", {
            "symbol": TRADING_PAIR,
            "interval": interval,
            "limit": limit
        })
        if not data:
            return []
        return [{
            "open":   float(c[1]),
            "high":   float(c[2]),
            "low":    float(c[3]),
            "close":  float(c[4]),
            "volume": float(c[5]),
            "time":   c[0]
        } for c in data]

    def get_order_book(self, limit=10) -> dict:
        return self._get("/api/v3/depth", {"symbol": TRADING_PAIR, "limit": limit})

    # ── Account ──────────────────────────────────────────────

    def get_balances(self) -> dict:
        data = self._get("/api/v3/account", signed=True)
        if not data:
            return {}
        return {
            b["asset"]: float(b["free"])
            for b in data.get("balances", [])
            if float(b["free"]) > 0 or b["asset"] in ("BTC", "USDT", "USD")
        }

    def get_usdt_balance(self) -> float:
        b = self.get_balances()
        return b.get("USD", b.get("USDT", 0.0))

    def get_btc_balance(self) -> float:
        return self.get_balances().get("BTC", 0.0)

    def get_open_orders(self) -> list:
        return self._get("/api/v3/openOrders", {"symbol": TRADING_PAIR}, signed=True) or []

    # ── Orders ───────────────────────────────────────────────

    def buy_market(self, usd_amount: float) -> dict:
        usd_amount = min(usd_amount, MAX_POSITION_SIZE_USD)
        logger.info(f"BUY MARKET ${usd_amount:.2f}")
        return self._post("/api/v3/order", {
            "symbol":        TRADING_PAIR,
            "side":          "BUY",
            "type":          "MARKET",
            "quoteOrderQty": round(usd_amount, 2)
        })

    def sell_market(self, btc_amount: float) -> dict:
        logger.info(f"SELL MARKET {btc_amount:.8f} BTC")
        return self._post("/api/v3/order", {
            "symbol":   TRADING_PAIR,
            "side":     "SELL",
            "type":     "MARKET",
            "quantity": round(btc_amount, 8)
        })

    def buy_limit(self, price: float, usd_amount: float) -> dict:
        usd_amount = min(usd_amount, MAX_POSITION_SIZE_USD)
        qty = round(usd_amount / price, 8)
        logger.info(f"BUY LIMIT {qty} BTC @ ${price:.2f}")
        return self._post("/api/v3/order", {
            "symbol":      TRADING_PAIR,
            "side":        "BUY",
            "type":        "LIMIT",
            "timeInForce": "GTC",
            "quantity":    qty,
            "price":       f"{price:.2f}"
        })

    def sell_limit(self, price: float, btc_amount: float) -> dict:
        logger.info(f"SELL LIMIT {btc_amount:.8f} BTC @ ${price:.2f}")
        return self._post("/api/v3/order", {
            "symbol":      TRADING_PAIR,
            "side":        "SELL",
            "type":        "LIMIT",
            "timeInForce": "GTC",
            "quantity":    round(btc_amount, 8),
            "price":       f"{price:.2f}"
        })

    def cancel_order(self, order_id: int) -> dict:
        return self._delete("/api/v3/order", {
            "symbol":  TRADING_PAIR,
            "orderId": order_id
        })

    def cancel_all_orders(self):
        orders = self.get_open_orders()
        for o in orders:
            self.cancel_order(o["orderId"])
        logger.info(f"Cancelled {len(orders)} open orders")

    def get_order(self, order_id: int) -> dict:
        return self._get("/api/v3/order", {
            "symbol":  TRADING_PAIR,
            "orderId": order_id
        }, signed=True)
