"""
Dashboard — run separately to monitor bot status.
Usage: python dashboard.py
Shows live P&L, positions, sweep status, recent trades.
"""

import json
import os
import time
from datetime import datetime
from engine.exchange import BinanceClient
from config import BOT1_CAPITAL_USD, BOT2_CAPITAL_USD, RESERVE_USD, LOG_DIR


def clear():
    os.system("clear" if os.name == "posix" else "cls")


def load_trades(n=10):
    path = os.path.join(LOG_DIR, "trades.jsonl")
    if not os.path.exists(path):
        return []
    with open(path) as f:
        lines = f.readlines()
    trades = []
    for line in lines[-n:]:
        try:
            trades.append(json.loads(line))
        except Exception:
            pass
    return trades


def load_risk_state():
    path = os.path.join(LOG_DIR, "risk_state.json")
    if not os.path.exists(path):
        return {}
    with open(path) as f:
        return json.load(f)


def main():
    client   = BinanceClient()
    baseline = BOT1_CAPITAL_USD + BOT2_CAPITAL_USD + RESERVE_USD

    while True:
        clear()
        now   = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        price = client.get_price() or 0
        bal   = client.get_usdt_balance()
        btc   = client.get_btc_balance()
        risk  = load_risk_state()
        trades = load_trades(8)

        profit     = bal - baseline
        profit_pct = (profit / baseline * 100) if baseline else 0
        killed     = risk.get("killed", False)
        dd_start   = risk.get("daily_start_balance", baseline)
        dd_pct     = ((dd_start - bal) / dd_start * 100) if dd_start else 0

        status_icon = "🔴 KILLED" if killed else "🟢 RUNNING"

        print("=" * 58)
        print(f"  BTC ACCUMULATION BOT DASHBOARD — {now}")
        print("=" * 58)
        print(f"  Status        : {status_icon}")
        print(f"  BTC Price     : ${price:>12,.2f}")
        print()
        print("  ── Binance.US Account ──────────────────────────")
        print(f"  USD Balance   : ${bal:>12,.2f}")
        print(f"  BTC Balance   : {btc:>13.8f} BTC")
        print(f"  Baseline      : ${baseline:>12,.2f}")
        pnl_sym = "+" if profit >= 0 else ""
        print(f"  P&L           : {pnl_sym}${profit:>11,.2f}  ({pnl_sym}{profit_pct:.2f}%)")
        print(f"  Daily Drawdown: {dd_pct:.2f}%  (limit: 5.00%)")
        print()
        print("  ── Recent Trades ───────────────────────────────")
        if trades:
            for t in reversed(trades):
                ts    = t.get("time", "")[:19]
                bot   = t.get("bot", "")
                side  = t.get("side", "")
                px    = t.get("price", 0)
                amt   = t.get("amount_usd", 0)
                side_icon = "▲" if "BUY" in side else "▼"
                print(f"  {side_icon} {ts}  {bot:<14} {side:<12} ${amt:>8,.2f} @ ${px:>10,.2f}")
        else:
            print("  No trades yet")
        print()
        print("  ── Commands ────────────────────────────────────")
        print("  Reset kill switch : python main.py --reset-kill")
        print("  View full logs    : tail -f logs/bot_*.log")
        print("=" * 58)

        time.sleep(15)


if __name__ == "__main__":
    main()
